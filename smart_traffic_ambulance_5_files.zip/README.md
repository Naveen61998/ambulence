# Smart Traffic Light - Ambulance Prioritization

A beginner-friendly front-end project that simulates a smart traffic management system.

## Files

1. `index.html` - Main webpage structure.
2. `style.css` - Complete responsive styling.
3. `script.js` - Traffic simulation, ambulance priority, ETA, route progress and activity log.
4. `data.js` - Sample traffic signal and ambulance data.
5. `README.md` - Project documentation.

## Features

- Live traffic signal simulation
- Ambulance list and emergency status
- One-click ambulance priority
- Automatically changes route signals to green
- Estimated time saved
- Emergency route progress
- Activity/event log
- Responsive design for mobile and desktop

## Run

Keep all five files in the same folder and open `index.html` in a browser.

## GitHub

Create a repository, upload all five files, and enable GitHub Pages from:
Settings -> Pages -> Deploy from branch -> main -> root.

## Future Full-Stack Upgrade

For a Java full-stack version, the front end can connect to:
- Java Spring Boot REST API
- MySQL database
- JWT login for admin/traffic officers
- Real ambulance GPS data
- WebSocket for real-time signal updates
- Maps API for route calculation

This demo is a simulation and does not control real traffic infrastructure.
