const signalData = [
  {id:1,name:"Signal A",location:"Main Road",state:"red"},
  {id:2,name:"Signal B",location:"Hospital Junction",state:"green"},
  {id:3,name:"Signal C",location:"Market Road",state:"red"},
  {id:4,name:"Signal D",location:"Ring Road",state:"yellow"}
];

const ambulanceData = [
  {id:"AMB-101",driver:"Emergency Unit 1",distance:"1.2 km",eta:"4 min",status:"Approaching Signal A"},
  {id:"AMB-102",driver:"Emergency Unit 2",distance:"2.7 km",eta:"8 min",status:"Approaching Hospital Junction"}
];
