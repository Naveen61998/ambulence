let signals = JSON.parse(JSON.stringify(signalData));
let ambulances = JSON.parse(JSON.stringify(ambulanceData));
let priorityActive = false;
let savedMinutes = 0;
let progress = 0;

const signalsEl = document.getElementById("signals");
const ambulancesEl = document.getElementById("ambulances");
const logEl = document.getElementById("activityLog");

function renderSignals(){
  signalsEl.innerHTML = signals.map(s => `
    <div class="signal">
      <div><h3>${s.name}</h3><small>${s.location}</small></div>
      <div class="lights">
        <span class="light red ${s.state==="red"?"active":""}"></span>
        <span class="light yellow ${s.state==="yellow"?"active":""}"></span>
        <span class="light green ${s.state==="green"?"active":""}"></span>
      </div>
    </div>`).join("");
}

function renderAmbulances(){
  ambulancesEl.innerHTML = ambulances.map(a => `
    <div class="ambulance">
      <strong>🚑 ${a.id}</strong>
      <div>${a.driver}</div>
      <small>${a.distance} away • ETA ${a.eta}<br>${a.status}</small><br>
      <button class="priority-btn" onclick="activatePriority('${a.id}')">Give Priority</button>
    </div>`).join("");
}

function addLog(message){
  const time = new Date().toLocaleTimeString();
  logEl.insertAdjacentHTML("afterbegin", `<div class="log-item"><span>${time}</span>${message}</div>`);
}

function activatePriority(id){
  priorityActive = true;
  document.getElementById("systemMode").textContent = "Emergency";
  document.getElementById("routeStatus").textContent = `Priority active for ${id}`;
  document.getElementById("routeStatus").style.background = "#fee2e2";
  document.getElementById("routeStatus").style.color = "#b91c1c";

  signals = signals.map(s => ({...s,state:"green"}));
  document.getElementById("prioritySignals").textContent = signals.length;
  savedMinutes += 6;
  document.getElementById("savedTime").textContent = savedMinutes + " min";
  document.getElementById("eta").textContent = "2 min";
  progress = 70;
  document.getElementById("routeProgress").style.width = progress + "%";
  renderSignals();
  addLog(`🚨 <b>${id}</b> received emergency priority. All route signals set to GREEN.`);
}

document.getElementById("emergencyBtn").addEventListener("click",()=>{
  activatePriority(ambulances[0].id);
});

document.getElementById("refreshBtn").addEventListener("click",()=>{
  if(!priorityActive){
    signals = signals.map(s=>{
      const states=["red","yellow","green"];
      return {...s,state:states[Math.floor(Math.random()*states.length)]};
    });
  }
  renderSignals();
  addLog("🔄 Traffic signal status refreshed.");
});

document.getElementById("clearLogBtn").addEventListener("click",()=>{
  logEl.innerHTML = "";
  addLog("Activity log cleared.");
});

function normalTrafficCycle(){
  if(priorityActive) return;
  signals = signals.map((s,i)=>{
    const cycle=["red","green","yellow"];
    return {...s,state:cycle[(Math.floor(Date.now()/4000)+i)%3]};
  });
  renderSignals();
}
setInterval(normalTrafficCycle,1000);

renderSignals();
renderAmbulances();
addLog("✅ Smart traffic control system initialized.");
addLog("📡 Traffic signals connected successfully.");
